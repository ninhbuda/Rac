import re
from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from zlapi import Message, ThreadType, Mention, MessageStyle, MultiMsgStyle
import time
from datetime import datetime
import threading
import json
def lenhadminvip():
    try:
        with open('admin.json', 'r') as adminvip:
            adminzalo = json.load(adminvip)
            return set(adminzalo.get('idadmin', []))
    except FileNotFoundError:
        return set()
        print(f"\033[34m{message} \033[39m|\033[31m {author_id}\033[0m\n")
idadmin = lenhadminvip()
class zalo_bot_tmr(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.spamming = False
        self.spam_thread = None
        self.spammingvip = False
        self.spam_threadvip = None
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"\033[34m{message} \033[39m|\033[31m {author_id}\033[0m\n")
        content = message_object.content if message_object and hasattr(message_object, 'content') else ""
        if not isinstance(message, str):
            print(f"{type(message)}")
            return
        elif message.startswith("info"):
            user_id = None
            if message_object.mentions:
                user_id = message_object.mentions[0]['uid']
            elif content[5:].strip().isnumeric():
                user_id = content[5:].strip()
            else:
                user_id = author_id
            user_info = self.fetchUserInfo(user_id)
            infozalo = self.checkinfo(user_id, user_info)
            self.replyMessage(Message(text=infozalo, parse_mode="HTML"), message_object, thread_id=thread_id, thread_type=thread_type)
            return
        elif message.startswith("spamvip"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 Chỉ ĐẸPTRAI mới dùng được lệnh này!.'), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            args = content.split()
            if len(args) >= 3:
                message = " ".join(args[1:-1])
                try:
                    delay = float(args[-1])
                    if delay < 0:
                        self.replyMessage(Message(text='🚫 Delay Nhập Cho Chuẩn Vào'), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                    self.chayspamvip(message, delay, thread_id, thread_type)
                except ValueError:
                    self.replyMessage(Message(text='🚫 Nhập Delay Vào'), message_object, thread_id=thread_id, thread_type=thread_type)
            else:
                self.replyMessage(Message(text='🚫 Sử dụng:\nspamvip [ Nội Dung ] [ Delay ]\n\n/spam ĐẸPTRAI 5'), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith("stopspamvip"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 Chỉ ĐẸPTRAI mới dùng được lệnh này!.'), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            self.dungspamvip()
            self.replyMessage(Message(text='Stop Spam'), message_object, thread_id=thread_id, thread_type=thread_type)
    def chayspamvip(self, message, delay, thread_id, thread_type):
        if self.spammingvip:
            self.dungspamvip()
        self.spammingvip = True
        self.spam_threadvip = threading.Thread(target=self.spamtagallvip, args=(message, delay, thread_id, thread_type))
        self.spam_threadvip.start()
    def dungspamvip(self):
        if self.spammingvip:
            self.spammingvip = False
            if self.spam_threadvip is not None:
                self.spam_threadvip.join()
            self.spam_threadvip = None
    def spamtagallvip(self, message, delay, thread_id, thread_type):
        while self.spammingvip:
            mention = Mention(uid='-1', offset=0, length=0)
            zalo_bot_tmr.send(Message(text=message, mention=mention), thread_id=thread_id, thread_type=thread_type)
            time.sleep(delay)
    def checkinfo(self, user_id, user_info):
        if 'changed_profiles' in user_info and user_id in user_info['changed_profiles']:
            profile = user_info['changed_profiles'][user_id]
            infozalo = f'''
<b>Tên: </b> {profile.get('displayName', '')}
<b>ID: </b> {profile.get('userId', '')}
            '''
            return infozalo
        else:
            return "Chịu Dell Thấy Người Dùng Này Á."
#Nhập Imei Lấy Từ Acc Zalo Á
imei = ""
#Nhập Cookie
session_cookies =  {}
zalo_bot_tmr = zalo_bot_tmr('api_key', 'secret_key', imei=imei, session_cookies=session_cookies)
zalo_bot_tmr.listen()