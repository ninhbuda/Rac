import json
import os

file_path = 'use.txt'

key = "light"
admin = []
group = []

ho_tro = """        

➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡
☣ ✅**block** ✖Khoá Mõm Bọn Gay Cube😏
➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡
☣ 🔞**unlock** ✖Mở Mõm Bọn Gay FF✖ 🔳
➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡
☣ 📊 **bxh** 📛Check Bxh Nhắn Tin   📛
➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡➡
   ────(★)(★)(★)────(★)(★)(★) __ wɧєη уσυ’rє ƖσηєƖу,
──(★)██████(★)(★)██████(★) ɪ’ƖƖ вє уσυя Ƈσмραηιση.
─(★)████████(★)████████(★) ɪƒ уσυ ηєє∂ α Ɠιgglє,
─(★)██████████████████(★) ɪ’ƖƖ вє уσυя ƁυввƖє.
──(★)████████████████(★) ɪƒ уσυ ηєє∂ α Ƒяєєzє,
────(★)█████💗█████(★) __ ɪ’ƖƖ вє уσυя Вяєєzє.
──────(★)████████(★) ɪƒ уσυ ωαηт тσ ƨηαρ ραє,
────────(★)████(★) __ ɪ’ƖƖ вє уσυя ƨρσят.
─────────(★)██(★) ƒσя єνєя уσυ ηєє∂ α Ɠυιdє,
───────────(★) __ ɪ’ƖƖ вє ƒσя уσυ <3
    
   

"""



contronl = ["unlock" , "block" , "game" , "bxh"]
                    



def Getkey():
    return key

def Add_Admin(ad):
    admin.append(ad)
    
def Check(ad):
    if ad in admin:
        return True 
    else:
        return False

def Add_Grop(gr):
    group.append(gr)
    
def Check_Grop(gr):
    if gr in group:
        return True
    else:
        return False

def Check_Lenh(text):
    if text in contronl:
        return contronl.index(text)
    else:
        return -1
def Remove(text):
    if text in group:
        group.remove(text)  
        
def ConCac():
    return ho_tro
    
        