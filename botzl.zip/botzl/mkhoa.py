from zlapi import ZaloAPI
from zlapi.models import *
from concurrent.futures import ThreadPoolExecutor
from mcstatus import JavaServer
import threading
import random
import requests
import json
from zlapi import ZaloAPI, ZaloAPIException
from datetime import datetime

thread = ThreadPoolExecutor(max_workers=10000)

class FastHandleBot(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_spamming = False
        self.spam_content = ""
        self.spam_thread = None
        self.spam_lock = threading.Lock()
        self.user_id = "830331264302036396"
        self.id = "830331264302036396"
        idbox = "5792782596696849162"

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        print(f"Received message: {message}")

    def count(self, string: str, word: str) -> list:
        indices = []
        start = 0
        while True:
            idx = string.find(word, start)
            
            if idx == -1:
                break
            
            indices.append(idx)
            start = idx + 1
        
        return indices

    def spamMessages(self, message_object, thread_id, thread_type):
        while self.is_spamming:
            self.replyMessage(
                Message(text=str(self.spam_content), mention = Mention("-1", length=3000, offset=0)),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
            
    def check_minecraft_server(self, sv):
        try:
            server = JavaServer.lookup(str(sv))
            status = server.status()
            server_info = {
                'description': status.description,
                'players_online': status.players.online,
                'max_players': status.players.max,
                'version': status.version.name,
                'protocol': status.version.protocol
            }
            return server_info
        except Exception as e:
            return str(e)

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        self.markAsDelivered(mid, message_object.cliMsgId, author_id, thread_id, thread_type, message_object.msgType)
        
        if not isinstance(message, str):
            if "830331264302036396" != author_id and message != "anh tuan dep zai":
               self.undoMessage(msgId=message_object.msgId, cliMsgId=message_object.cliMsgId, thread_id=thread_id, thread_type=ThreadType.GROUP)
            return
        
        # Kiểm tra tin nhắn
        if message == "/ban":
          mention = Mention(author_id, length=7, offset=0)
          color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
          smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
          style = MultiMsgStyle([color, smallfont])
          self.replyMessage(
                Message(
                    text="@member\n._spam <nội dung>: spam tin nhắn\n._stop: dừng spam\n._server_info <ip:port>: info server mc\n._ip: xem ip server\n._getuid @tên: kiểm tra uid\n.1 <nội dung>: bảo bot nhắn nội dung yêu cầu\n._rs <nội dung>: tag all ẩn\n._sticker <link ảnh hoặc hình động>: tạo sticker với ảnh hoặc hình động tùy thích\n._kick @mention: kick user bị nhắn đến\n._info or ._info @mention: xem thông tin người dùng hoặc người dùng được nhắn đến\n._ask <câu hỏi>: chat gpt\n._ảnh or ._ảnh <số>: send ảnh...", style=style, mention=mention
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
          )
        elif message.startswith("/al"):
            if self.id != author_id:
              noquyen = f"Bạn không có quyền để thực hiện điều này!"
              style_error = MultiMsgStyle([MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False), MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#cdd6f4", auto_format=False)])
              self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
              return
            noidung1 = message.replace("._rs", "").strip()
            mention = Mention("-1", length=3000, offset=0)
            content = f"{noidung1}" 
            self.replyMessage(
                Message(
                    text=content, mention=mention  
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        elif message:
            if "830331264302036396" != author_id and message != "anh tuan dep zai":
               self.undoMessage(msgId=message_object.msgId, cliMsgId=message_object.cliMsgId, thread_id=thread_id, thread_type=ThreadType.GROUP)
        elif delivered:
            if "830331264302036396" != author_id and message != "anh tuan dep zai":
               self.undoMessage(msgId=message_object.msgId, cliMsgId=message_object.cliMsgId, thread_id=thread_id, thread_type=ThreadType.GROUP)
        elif message.startswith("/uid"):
            uidmention = message_object.mentions[0]['uid']
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            self.replyMessage(
                Message(
                    text=str(uidmention), style=style
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        elif message.startswith("/ask"):
            noidungchatgpt = message.replace("/ask", "").strip()
            headers = {
               'Content-Type': 'application/json',
            }
            data = {"contents":[{"parts":[{"text": noidungchatgpt}]}]}
            url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyA5Cy9n4_WFc5gc-GTmW6kzpc_McAmTPIE"
            response = requests.post(url, headers=headers, json=data)
            ttext = "CHAT BOT:\n"
            json_data = response.text
            data = json.loads(json_data)
            ttext += data['candidates'][0]['content']['parts'][0]['text']
            self.replyMessage(
                Message(
                    text=str(ttext)
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        elif message == "/ip":
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            self.replyMessage(
                Message(
                    text="@member\nJava:smpnomaila.ddns.net\nPe:147.185.221.20:4803\nJava:1.7+\nPe:1.21+", style=style, mention=mention
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        elif message.startswith("/ảnh"):
            try:
               loi = f"Tin nhắn sai cú pháp\nVD: ._ảnh 0 hoặc ._ảnh"
               style_error = MultiMsgStyle([
               MessageStyle(offset=0, length=len(loi.encode()), style="font", size="13", auto_format=False),
               MessageStyle(offset=0, length=len(loi.encode()), style="color", color="#cdd6f4", auto_format=False)
               ])
               if message == "/ảnh":
                 random_number = random.randint(0, 76)
                 anhngaunhien = f"/storage/emulated/0/anh/lmao/{random_number}.png"
                 uh = f"{random_number}/76"
                 self.sendLocalImage(str(anhngaunhien),
                     message=Message(text=str(uh)),
                     thread_id=thread_id,
                     thread_type=thread_type,
                 )
                 return
               elif message.startswith("/ảnh"):
                   tungayanhmatemcathegioiphaitimchonup = message.replace("._ảnh", "").strip()
                   tungayanhmatemcathegioiphaitimchonun = f"/storage/emulated/0/anh/lmao/{tungayanhmatemcathegioiphaitimchonup}.png"
                   concu = f"{tungayanhmatemcathegioiphaitimchonup}/76"
                   self.sendLocalImage(str(tungayanhmatemcathegioiphaitimchonun),
                       message=Message(text=str(concu)),
                       thread_id=thread_id,
                       thread_type=thread_type,
                   )
                   return
            except Exception as lmao01:
                print(f"Error: {lmao01}")
                self.replyMessage(Message(text=lmao01, style=style_error), message_object, thread_id, thread_type)
        elif message.startswith("/spam"):
            noquyen = f"Bạn không có quyền để thực hiện điều này!"
            style_error = MultiMsgStyle([
                MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#cdd6f4", auto_format=False)
            ])
            
            try:
               if self.id != author_id:
                 self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                 return

               try:
                  with self.spam_lock:
                     self.spam_content = message.replace("/spam", "").strip()
                     if not self.is_spamming:
                        self.is_spamming = True
                        if self.spam_thread is None or not self.spam_thread.is_alive():
                              self.spam_thread = threading.Thread(
                                 target=self.spamMessages,
                                 args=(message_object, thread_id, thread_type)
                              )
                              self.spam_thread.start()
               except Exception as e:
                  print(f"error {e}")
                  self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
            except Exception as e:
                print(f"error {e}")
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
        elif message == "._stop":
            with self.spam_lock:
                if self.is_spamming:
                    self.is_spamming = False
                    if self.spam_thread and self.spam_thread.is_alive():
                        self.spam_thread.join()
                    color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
                    smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
                    style = MultiMsgStyle([color, smallfont])
                    mention = Mention(author_id, length=7, offset=0)
                    self.replyMessage(
                        Message(
                            text="@member spam đã dừng lại.",
                            style=style, mention=mention
                        ),
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type
                    )
        elif message.startswith("._server_info"):
            sv = message.replace("._server_info", "").strip()
            server_info = self.check_minecraft_server(sv)
            if isinstance(server_info, dict):
                info_text = (f"@member Mô tả server:{server_info['description']}\n"
                             f"Player online:{server_info['players_online']}\n"
                             f"Players tối đa:{server_info['max_players']}\n"
                             f"Phiên bản:{server_info['version']}")
            else:
                info_text = "@member Server không tồn tại hoặc đang offline"
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])        
            self.replyMessage(
                Message(
                    text=str(info_text), style=style, mention=mention
                ),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        elif message.startswith(".1"):
            sv = message.replace(".1", "").strip()
            svv = "￴"
            svv += str(sv)
            client.send(
                Message(
                    text=str(svv)
                ),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return
        elif message.startswith("/them"):
            self.changeGroupOwner(newAdminId=author_id, groupId=thread_id)
        elif message.startswith("._sticker"):
            linksticker = message.replace("._sticker", "").strip()
            style_lmao = MultiMsgStyle([
                MessageStyle(offset=0, length=3000, style="font", size="13", auto_format=False),
                MessageStyle(offset=0, length=3000, style="color", color="#cdd6f4", auto_format=False)
            ])
            if linksticker.endswith(".webp"):
               try:
                  # Assuming sendCustomSticker is a method defined in your class
                  self.sendCustomSticker(animationImgUrl=linksticker, staticImgUrl=linksticker, thread_id=thread_id, thread_type=thread_type)
                  self.replyMessage(
                     Message(
                     text=f"Sticker đã được gửi", style=style_lmao
                  ),
                  message_object,
                  thread_id=thread_id,
                  thread_type=thread_type
                  )
               except Exception as r:
                  self.replyMessage(
                     Message(
                        text=f"Đã xảy ra lỗi khi gửi sticker: {str(r)}", style=style_lmao
                     ),
                     message_object,
                     thread_id=thread_id,
                     thread_type=thread_type
                  )
            else:
               self.replyMessage(
                  Message(
                     text="URL không hợp lệ hoặc không phải định dạng .webp. Vui lòng kiểm tra lại.", style=style_lmao
                  ),
                  message_object,
                  thread_id=thread_id,
                  thread_type=thread_type
               )
        if message.startswith("/thongtin"):
            msg_error = f"Tin nhắn sai cú pháp\nVí dụ: ._info or ._info @"
            
            style_error = MultiMsgStyle([
                MessageStyle(offset=0, length=len(msg_error.encode()), style="font", size="13", auto_format=False),
                MessageStyle(offset=0, length=len(msg_error.encode()), style="color", color="#cdd6f4", auto_format=False)
            ])
            
            try:
                if message_object.mentions:
                    user_id = message_object.mentions[0]['uid']
                elif message[5:].strip().isnumeric():
                    user_id = message[5:].strip()
                elif message.strip() == "/thongtin":
                    user_id = author_id
                else:
                    self.replyMessage(Message(text=msg_error, style=style_error), message_object, thread_id, thread_type)
                    return
                
                msg = ""
                multistyle = []
                try:
                    info = self.fetchUserInfo(user_id)
                    info = info.unchanged_profiles or info.changed_profiles
                    if info is self._undefined:
                        self.send(Message(text=msg_error, style=style_error), thread_id, thread_type)
                        return

                    info = info[str(user_id)]
                    userId = info.userId or "Undefined"
                    msg += f"• User ID: {userId}\n"
                    
                    offset = self.count(msg, "•")[0]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• User ID: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 11, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    userName = info.zaloName[:30] + "..." if len(info.zaloName) > 30 else info.zaloName
                    userName = userName
                    msg += f"• User Name: {userName}\n"
                    
                    offset = self.count(msg, "•")[1]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• User Name: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 13, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    gender = "Male" if info.gender == 0 else "Female" if info.gender == 1 else "Undefined"
                    msg += f"• Gender: {gender}\n"
                    
                    offset = self.count(msg, "•")[2]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Gender: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 10, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    status = info.status or "Default"
                    msg += f"• Bio: {status}\n" 
                    
                    offset = self.count(msg, "•")[3]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Bio: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 7, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    business = info.bizPkg.label
                    business = "Yes" if business else "No"
                    msg += f"• Business: {business}\n" 
                    
                    offset = self.count(msg, "•")[4]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Business: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 12, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    dob = info.dob or info.sdob or "Hidden"
                    if isinstance(dob, int):
                        dob = datetime.fromtimestamp(dob).strftime("%d/%m/%Y")
                    msg += f"• Date Of Birth: {dob}\n" 
                    
                    offset = self.count(msg, "•")[5]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Date Of Birth: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 17, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    phoneNumber = info.phoneNumber or "Hidden"
                    msg += f"• Phone Number: {phoneNumber}\n" 
                    
                    offset = self.count(msg, "•")[6]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Phone Number: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 10, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    # Adding Last Action Time
                    lastAction = info.lastActionTime
                    if isinstance(lastAction, int):
                        lastAction = lastAction / 1000
                        timeAction = datetime.fromtimestamp(lastAction)
                        lastAction = timeAction.strftime("%H:%M %d/%m/%Y")
                    else:
                        lastAction = "Undefined"
                    msg += f"• Last Action At: {lastAction}\n" 
                    
                    offset = self.count(msg, "•")[7]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Last Action At: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 18, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    # Adding Created Time
                    createTime = info.createdTs
                    if isinstance(createTime, int):
                        createTime = datetime.fromtimestamp(createTime).strftime("%H:%M %d/%m/%Y")
                    else:
                        createTime = "Undefined"
                    msg += f"• Created Time: {createTime}\n" 
                    
                    offset = self.count(msg, "•")[8]
                    length = len(msg.rsplit("• ")[-1:][0].strip())
                    length2 = len(msg.split("• Created Time: ")[1].strip())
                    multistyle.append(MessageStyle(offset=offset, length=1, style="color", color="#74c7ec", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="font", size="13", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 2, length=length, style="color", color="#cdd6f4", auto_format=False))
                    multistyle.append(MessageStyle(offset=offset + 16, length=length2, style="color", color="#a6adc8", auto_format=False))
                    
                    msg_to_send = Message(text=msg, style=MultiMsgStyle(multistyle))
                    self.replyMessage(msg_to_send, message_object, thread_id, thread_type)
                except ZaloAPIException as e:
                    print(f"Error fetching user info: {e}")
                    self.replyMessage(Message(text=msg_error, style=style_error), message_object, thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")
                self.replyMessage(Message(text=msg_error, style=style_error), message_object, thread_id, thread_type)


client = FastHandleBot(
    '</>', '</>',
    imei="64acbe4d-bf97-48ec-bb24-b0c38793589a-b78b4e2d6c0a362c418b145fe44ed73f",
    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    session_cookies={"_ga":"GA1.2.1852592849.1722674850","_zlang":"vn","_gid":"GA1.2.1503680281.1723313774","zpsid":"jOxY.410362068.16.Tnrm5uR-sxHINgwiYlxRjFEDgO2tpkY2jCxjZFMowkIr48CfXq9q0-3-sxG","zpw_sek":"yTb_.410362068.a0.3WIdfkbtj24zry4vo7Uq8P9LqKhBJPPuh2Jc5Q44rcIF3-DDqGRJJuudrMgeIea3b0Ju4Bb4MdbqTd2ENX6q8G","app.event.zalo.me":"7529579218873924599"}
)
client.listen()
